import {
  BrowserAnimationsModule,
  InjectableAnimationEngine,
  NoopAnimationsModule,
  provideAnimations,
  provideNoopAnimations
} from "./chunk-Y4N3QGD7.js";
import "./chunk-NRNVPPSC.js";
import "./chunk-X2XCIAXE.js";
import {
  ANIMATION_MODULE_TYPE
} from "./chunk-M2HKNXBA.js";
export {
  ANIMATION_MODULE_TYPE,
  BrowserAnimationsModule,
  NoopAnimationsModule,
  provideAnimations,
  provideNoopAnimations,
  InjectableAnimationEngine as ɵInjectableAnimationEngine
};
//# sourceMappingURL=@angular_platform-browser_animations.js.map
